from django.shortcuts import render



def main(request):
    context = {
        'slogan': 'СУПЕР УДОБНЫЕ СТУЛЬЯ',
        'topic': 'ТРЕНДЫ'
    }
    return render(request, 'index.html', context=context)

def contact(request):
    return render(request, 'contact.html')